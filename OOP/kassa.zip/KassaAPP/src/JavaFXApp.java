import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class JavaFXApp extends Application
{

    @Override
    public void start(Stage primaryStage) throws Exception
    {
        GridPane root = new GridPane();
        GuiHandler gui = new GuiHandler(root);
        primaryStage.setTitle("test");
        primaryStage.setScene(new Scene(root, 1080, 1024));
        primaryStage.show();
    }


    public static void main(String[] args)
    {
        launch(args);
    }
}