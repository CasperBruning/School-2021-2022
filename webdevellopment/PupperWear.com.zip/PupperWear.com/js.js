document.querySelector('#product1').addEventListener("onmouseenter", function (){
    document.querySelector('#productinfo1').style.opacity = 1;
})